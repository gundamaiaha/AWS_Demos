package com.example.quizmasterservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizMasterServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
