package com.example.quizmasterservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizMasterServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizMasterServiceApplication.class, args);
	}

}
