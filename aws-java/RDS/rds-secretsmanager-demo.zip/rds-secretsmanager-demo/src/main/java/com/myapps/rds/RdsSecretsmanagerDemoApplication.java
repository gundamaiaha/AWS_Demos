package com.myapps.rds;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdsSecretsmanagerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdsSecretsmanagerDemoApplication.class, args);
	}

}
